package service;

import model.Comment;
import java.util.ArrayList;
import java.util.List;

public class CommentService {

    // 댓글을 데이터베이스에 추가하는 메서드
    public static void addComment(int postId, String commentText, String userId) {
        // 데이터베이스 연결 및 댓글 저장 로직 추가
        // 예시로는 임시로 콘솔에 출력만 함
        System.out.println("Adding comment to post ID " + postId + ": " + commentText + " by user " + userId);
        
        // 실제 구현에서는 데이터베이스 코드가 여기에 들어갑니다.
    }

    // 댓글을 특정 게시글의 댓글을 가져오는 메서드
    public static List<Comment> getComments(int postId) {
        List<Comment> comments = new ArrayList<>();

     
       
        return comments;
    }
}
