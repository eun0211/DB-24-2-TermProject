package service;

import model.User;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

public class UserService {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/twitter_t";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "gun13!40a123";

    public static User getUser(String userId) {
        String sql = "SELECT user_id, followers_count, following_count FROM user WHERE user_id = ?";
        User user = null;

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    user = new User(
                        rs.getString("user_id"),
                        rs.getInt("followers_count"),
                        rs.getInt("following_count")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    // 팔로우 추가
    public static boolean isFollowing(String currentUserId, String targetUserId) {
        String sql = "SELECT COUNT(*) FROM following WHERE user_id = ? AND following_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, currentUserId);
            pstmt.setString(2, targetUserId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0; // 0보다 크면 팔로우 중
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // 예외 발생 시 팔로우하지 않음
    }

    // 팔로우 기능
    public static void followUser(String currentUserId, String targetUserId) {
        String sqlCheckFollowing = "SELECT 1 FROM following WHERE user_id = ? AND following_id = ?";
        String sqlInsertFollowing = "INSERT INTO following (user_id, following_id) VALUES (?, ?)";
        String sqlUpdateFollowingCount = "UPDATE user SET following_count = following_count + 1 WHERE user_id = ?";
        String sqlUpdateFollowerCount = "UPDATE user SET followers_count = followers_count + 1 WHERE user_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            connection.setAutoCommit(false); // 트랜잭션 시작

            // 팔로우 중인지 확인
            if (!isFollowing(currentUserId, targetUserId)) {
                try (PreparedStatement pstmtCheck = connection.prepareStatement(sqlCheckFollowing);
                     PreparedStatement pstmtInsert = connection.prepareStatement(sqlInsertFollowing);
                     PreparedStatement pstmtUpdateFollowing = connection.prepareStatement(sqlUpdateFollowingCount);
                     PreparedStatement pstmtUpdateFollower = connection.prepareStatement(sqlUpdateFollowerCount)) {

                    pstmtCheck.setString(1, currentUserId);
                    pstmtCheck.setString(2, targetUserId);
                    try (ResultSet rs = pstmtCheck.executeQuery()) {
                        if (!rs.next()) {
                            // 팔로우 추가
                            pstmtInsert.setString(1, currentUserId);
                            pstmtInsert.setString(2, targetUserId);
                            pstmtInsert.executeUpdate();

                            // 팔로우 수 증가
                            pstmtUpdateFollowing.setString(1, currentUserId);
                            pstmtUpdateFollowing.executeUpdate();
                            pstmtUpdateFollower.setString(1, targetUserId);
                            pstmtUpdateFollower.executeUpdate();
                        }
                    }
                }
                connection.commit(); // 트랜잭션 커밋
                System.out.println(currentUserId + "이(가) " + targetUserId + "을(를) 팔로우했습니다.");
            } else {
                System.out.println(currentUserId + "은(는) 이미 " + targetUserId + "을(를) 팔로우하고 있습니다.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 롤백 처리
            try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                connection.rollback();
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
        }
    }

    // 언팔로우 기능
    public static void unfollowUser(String currentUserId, String targetUserId) {
        String sqlCheckFollowing = "SELECT 1 FROM following WHERE user_id = ? AND following_id = ?";
        String sqlDeleteFollowing = "DELETE FROM following WHERE user_id = ? AND following_id = ?";
        String sqlUpdateFollowingCount = "UPDATE user SET following_count = following_count - 1 WHERE user_id = ?";
        String sqlUpdateFollowerCount = "UPDATE user SET followers_count = followers_count - 1 WHERE user_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            connection.setAutoCommit(false); // 트랜잭션 시작

            if (isFollowing(currentUserId, targetUserId)) {
                try (PreparedStatement pstmtCheck = connection.prepareStatement(sqlCheckFollowing);
                     PreparedStatement pstmtDelete = connection.prepareStatement(sqlDeleteFollowing);
                     PreparedStatement pstmtUpdateFollowing = connection.prepareStatement(sqlUpdateFollowingCount);
                     PreparedStatement pstmtUpdateFollower = connection.prepareStatement(sqlUpdateFollowerCount)) {

                    pstmtCheck.setString(1, currentUserId);
                    pstmtCheck.setString(2, targetUserId);
                    try (ResultSet rs = pstmtCheck.executeQuery()) {
                        if (rs.next()) {
                            // 팔로우 관계 삭제
                            pstmtDelete.setString(1, currentUserId);
                            pstmtDelete.setString(2, targetUserId);
                            pstmtDelete.executeUpdate();

                            // 팔로우 수 감소
                            pstmtUpdateFollowing.setString(1, currentUserId);
                            pstmtUpdateFollowing.executeUpdate();
                            pstmtUpdateFollower.setString(1, targetUserId);
                            pstmtUpdateFollower.executeUpdate();
                        }
                    }
                }
                connection.commit(); // 트랜잭션 커밋
                System.out.println(currentUserId + "이(가) " + targetUserId + "을(를) 언팔로우했습니다.");
            } else {
                System.out.println(currentUserId + "은(는) " + targetUserId + "을(를) 팔로우하지 않았습니다.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 롤백 처리
            try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                connection.rollback();
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
        }
    }

    public static int getFollowerCount(String userId) {
        String sql = "SELECT followers_count FROM user WHERE user_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("followers_count");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; // 만약 해당 사용자가 없으면 0을 반환
    }

    public static int getFollowingCount(String userId) {
        String sql = "SELECT following_count FROM user WHERE user_id = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("following_count");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; // 만약 해당 사용자가 없으면 0을 반환
    }
    public static List<String> getFollowers(String userId) {
        List<String> followers = new ArrayList<>();
        String sql = "SELECT user_id FROM following WHERE following_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    followers.add(rs.getString("user_id"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return followers;
    }


    public static List<String> getFollowedUsers(String userId) {
        List<String> following = new ArrayList<>();
        String sql = "SELECT following_id FROM following WHERE user_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    following.add(rs.getString("following_id"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return following;
    }

    public static List<String> getFollowing(String userId) {
        List<String> following = new ArrayList<>();
        String sql = "SELECT following_id FROM following WHERE user_id = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    following.add(rs.getString("following_id"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return following;
    }

}
