package service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Comment;
import model.Post;
import twitter_t.DatabaseConnection;

/**
 * PostService 클래스
 * 데이터베이스와 상호작용하여 게시글 데이터를 관리하는 서비스.
 */
public class PostService {
    private static int postCounter = 0; // 포스트 아이디를 증가시킬 변수
    private static int commentCounter = 0; // 댓글 ID를 증가시킬 변수

    // 클래스 초기화 시 가장 큰 post_id 및 comment_id 값을 가져와서 초기화
    static {
        initializeCounters();
    }

    // 가장 큰 post_id와 comment_id 값을 데이터베이스에서 가져와서 초기화
    private static void initializeCounters() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            ResultSet rsPost = stmt.executeQuery("SELECT MAX(post_id) FROM posts");
            if (rsPost.next() && rsPost.getInt(1) > 0) {
                postCounter = rsPost.getInt(1);
            }
            ResultSet rsComment = stmt.executeQuery("SELECT MAX(comment_id) FROM comment");
            if (rsComment.next() && rsComment.getInt(1) > 0) {
                commentCounter = rsComment.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("데이터베이스 초기화 오류 발생.");
        }
    }

    // 게시글 목록 가져오기
    public static List<Post> getPosts() {
        List<Post> posts = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT * FROM posts");
            while (rs.next()) {
                int postId = rs.getInt("post_id");
                String text = rs.getString("text");
                String writerId = rs.getString("writer_id");
                int numOfLikes = rs.getInt("num_of_likes");
                posts.add(new Post(postId, text, writerId, numOfLikes));
            }
        } catch (SQLException e) {
            handleSQLException(e);
        }
        return posts;
    }

    // 사용자 ID로 게시글 목록 가져오기
    public static List<Post> getPostsByUser(String userId) {
        List<Post> posts = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM posts WHERE writer_id = ?")) {
            pstmt.setString(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int postId = rs.getInt("post_id");
                String text = rs.getString("text");
                int numOfLikes = rs.getInt("num_of_likes");
                posts.add(new Post(postId, text, userId, numOfLikes));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error retrieving posts by user: " + e.getMessage());
        }
        return posts;
    }

    // 특정 postId에 해당하는 게시글 가져오기
    public static Post getPost(int postId) {
        Post post = null;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM posts WHERE post_id = ?")) {
            pstmt.setInt(1, postId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String text = rs.getString("text");
                String writerId = rs.getString("writer_id");
                int numOfLikes = rs.getInt("num_of_likes");
                post = new Post(postId, text, writerId, numOfLikes);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return post;
    }

    // 댓글 목록 가져오기
    public static List<Comment> getComments(int postId) {
        List<Comment> comments = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM comment WHERE post_id = ? ORDER BY created_at ASC")) {
            pstmt.setInt(1, postId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int commentId = rs.getInt("comment_id");
                String userId = rs.getString("user_id");
                String content = rs.getString("text");
                comments.add(new Comment(commentId, String.valueOf(postId), userId, content));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return comments;
    }

    // 댓글 추가
    public static void addComment(int postId, String userId, String text) {
        int commentId = ++commentCounter; // 댓글 ID 증가
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                 "INSERT INTO comment (comment_id, post_id, user_id, text, created_at) VALUES (?, ?, ?, ?, NOW())")) {
            pstmt.setInt(1, commentId);
            pstmt.setInt(2, postId);
            pstmt.setString(3, userId);
            pstmt.setString(4, text);
            pstmt.executeUpdate();
            System.out.println("Comment added successfully with ID: " + commentId);
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("댓글 추가 중 오류 발생: " + e.getMessage());
        }
    }

    // 댓글 삭제
    public static void deleteComment(int commentId) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM comment WHERE comment_id = ?")) {
            pstmt.setInt(1, commentId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Comment deleted successfully with ID: " + commentId);
            } else {
                System.out.println("No comment found with ID: " + commentId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("댓글 삭제 중 오류 발생: " + e.getMessage());
        }
    }

    // 게시글 추가
    public static void addPost(String text, String userId) {
        int postId = ++postCounter; // 포스트 ID 증가
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(
                 "INSERT INTO posts (post_id, text, writer_id, num_of_likes, created_at) VALUES (?, ?, ?, 0, NOW())")) {
            pstmt.setInt(1, postId);
            pstmt.setString(2, text);
            pstmt.setString(3, userId);
            pstmt.executeUpdate();
            System.out.println("Post added successfully with ID: " + postId);
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error adding post: " + e.getMessage());
        }
    }

    // 게시글 삭제
    public static void deletePost(int postId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            // 먼저 댓글 삭제
            String deleteCommentsQuery = "DELETE FROM comment WHERE post_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(deleteCommentsQuery)) {
                stmt.setInt(1, postId);
                stmt.executeUpdate();
            }

            // 그 다음 포스트 삭제
            String deletePostQuery = "DELETE FROM posts WHERE post_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(deletePostQuery)) {
                stmt.setInt(1, postId);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.err.println("Error deleting post with ID: " + postId);
            e.printStackTrace();
        }
    }

    // 게시글 업데이트
    public static void updatePost(Post post) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE posts SET text = ?, num_of_likes = ? WHERE post_id = ?")) {
            pstmt.setString(1, post.getText()); // 수정된 부분: getText() -> getContent()
            pstmt.setInt(2, post.getNumOfLikes());
            pstmt.setInt(3, post.getPostId());
            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Post updated successfully with ID: " + post.getPostId());
            } else {
                System.out.println("No post found with ID: " + post.getPostId());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error updating post with ID: " + post.getPostId());
        }
    }

    // 예외 처리 유틸리티 메서드
    private static void handleSQLException(SQLException e) {
        e.printStackTrace();
        System.err.println("SQL 오류 발생: " + e.getMessage());
    }
}
