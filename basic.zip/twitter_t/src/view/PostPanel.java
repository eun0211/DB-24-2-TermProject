package view;

import javax.swing.*;
import model.Post;
import service.PostService;
import java.awt.*;
import java.util.List;

public class PostPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private String currentUserId; // 추가된 멤버 변수

    // 생성자에서 currentUserId 초기화
    public PostPanel(String currentUserId) {
        this.currentUserId = currentUserId; // 초기화
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        loadPosts();
    }

    private void loadPosts() {
        List<Post> posts = PostService.getPosts(); // PostService에서 글 데이터 가져오기
        if (posts == null || posts.isEmpty()) {
            JOptionPane.showMessageDialog(this, "게시글을 불러오는 데 실패했습니다. 다시 시도해주세요.", "경고", JOptionPane.WARNING_MESSAGE);
            return;
        }
        for (Post post : posts) {
            add(createPostComponent(post));
        }
    }

    private JPanel createPostComponent(Post post) {
        JPanel postPanel = new JPanel(new BorderLayout());
        JLabel userIdLabel = new JLabel("작성자: " + post.getPostId());
        JTextArea contentArea = new JTextArea(post.getText());
        contentArea.setEditable(false);

        // 좋아요 버튼과 댓글 섹션 추가
        JButton likeButton = new JButton("좋아요 (" + post.getNumOfLikes() + ")");
        likeButton.addActionListener(e -> {
            boolean isLiked = post.toggleLike(currentUserId);
            likeButton.setText("좋아요 (" + post.getNumOfLikes() + ")");
           // 타임라인 새로고침 (필요한 경우)
        });

        CommentPanel commentPanel = new CommentPanel(post.getPostId());

        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.add(likeButton);
        bottomPanel.add(commentPanel);

        postPanel.add(userIdLabel, BorderLayout.NORTH);
        postPanel.add(contentArea, BorderLayout.CENTER);
        postPanel.add(bottomPanel, BorderLayout.SOUTH);

        return postPanel;
    }

}
