package view;

import javax.swing.*;
import java.awt.*;
import service.PostService;

public class CommentPanel extends JPanel {
    private int postId; // int 타입으로 변경

    // 생성자
    public CommentPanel(int postId) {
        this.postId = postId; // int 타입으로 초기화
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        initializeComponents();
    }

    private void initializeComponents() {
        JLabel postLabel = new JLabel("댓글 섹션 (Post ID: " + postId + ")");
        add(postLabel);

        // 댓글 작성 입력란
        JTextField commentInput = new JTextField(20);
        JButton submitButton = new JButton("댓글 작성");
        submitButton.addActionListener(e -> {
            // 댓글 작성 로직을 추가할 수 있습니다.
            String commentText = commentInput.getText();
            if (!commentText.isEmpty()) {
                // PostService를 사용하여 댓글을 데이터베이스에 추가하는 메서드 호출
                PostService.addComment(postId, "사용자ID", commentText); // int 타입으로 전달
                commentInput.setText(""); // 댓글 작성 후 입력란 초기화
                JOptionPane.showMessageDialog(this, "댓글이 추가되었습니다.", "성공", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        add(commentInput);
        add(submitButton);
    }
}
