package model;

/**
 * 이다창(20241115)
 * Comment 모델 클래스
 * 각 댓글의 ID, 게시글 ID, 작성자 ID, 내용 등을 저장하는 클래스
 * 댓글 데이터를 구조화, 관리
 */
public class Comment {
    private int id;
    private String postId; // String으로 수정
    private String userId;
    private String content;

    public Comment(int id, String postId, String userId, String content) { // 생성자도 수정
        this.id = id;
        this.postId = postId;
        this.userId = userId;
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public String getPostId() { // 반환 타입도 수정
        return postId;
    }

    public String getUserId() {
        return userId;
    }

    public String getContent() {
        return content;
    }
    public String getAuthorId() {
        return getUserId(); // userId를 반환
    }

    public String getText() {
        return getContent(); // content를 반환
    }
}
