package model;

import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import twitter_t.DatabaseConnection; // 사용자 정의 클래스의 경로에 맞게 수정

public class Post {
    private int postId;
    private String text;
    private String writerId;
    private int numOfLikes;
    private Set<String> likedByUsers; // 좋아요를 누른 사용자 ID를 저장
    private List<Comment> comments; // 댓글을 Comment 객체로 관리

    public Post(int postId, String text, String writerId, int numOfLikes) {
        this.postId = postId;
        this.text = text;
        this.writerId = writerId;
        this.numOfLikes = numOfLikes;
        this.likedByUsers = new HashSet<>(); // 초기화
        this.comments = new ArrayList<>(); // 초기화
    }

    public boolean toggleLike(String userId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            // 좋아요가 이미 있는지 확인
            PreparedStatement checkStmt = conn.prepareStatement(
                "SELECT * FROM post_like WHERE post_id = ? AND user_id = ?");
            checkStmt.setInt(1, this.postId);
            checkStmt.setString(2, userId);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                // 이미 좋아요를 눌렀다면, 좋아요를 제거
                PreparedStatement deleteStmt = conn.prepareStatement(
                    "DELETE FROM post_like WHERE post_id = ? AND user_id = ?");
                deleteStmt.setInt(1, this.postId);
                deleteStmt.setString(2, userId);
                deleteStmt.executeUpdate();
                numOfLikes--; // 좋아요 수 감소

                // num_of_likes 업데이트
                PreparedStatement updateStmt = conn.prepareStatement(
                    "UPDATE posts SET num_of_likes = ? WHERE post_id = ?");
                updateStmt.setInt(1, numOfLikes);
                updateStmt.setInt(2, this.postId);
                updateStmt.executeUpdate();

                return false; // 좋아요 제거됨
            } else {
                // 좋아요를 누르지 않은 상태면 추가
                PreparedStatement insertStmt = conn.prepareStatement(
                    "INSERT INTO post_like (post_id, user_id) VALUES (?, ?)");
                insertStmt.setInt(1, this.postId);
                insertStmt.setString(2, userId);
                insertStmt.executeUpdate();
                numOfLikes++; // 좋아요 수 증가

                // num_of_likes 업데이트
                PreparedStatement updateStmt = conn.prepareStatement(
                    "UPDATE posts SET num_of_likes = ? WHERE post_id = ?");
                updateStmt.setInt(1, numOfLikes);
                updateStmt.setInt(2, this.postId);
                updateStmt.executeUpdate();

                return true; // 좋아요 추가됨
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error toggling like for post ID: " + this.postId);
            return false;
        }
    }

    // 댓글 추가 메서드
    public void addComment(String userId, String commentText) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO comment (post_id, user_id, text, created_at) VALUES (?, ?, ?, NOW())");
            stmt.setInt(1, this.postId);
            stmt.setString(2, userId);
            stmt.setString(3, commentText);
            stmt.executeUpdate();

            // 메모리에도 추가
            comments.add(new Comment(0, String.valueOf(this.postId), userId, commentText));
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error adding comment to post ID: " + this.postId);
        }
    }

    // 댓글 가져오기 메서드
    public void loadComments() {
        comments.clear(); // 기존 데이터 초기화
        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                "SELECT id, user_id, comment_text FROM comments WHERE post_id = ? ORDER BY created_at ASC");
            stmt.setInt(1, this.postId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String userId = rs.getString("user_id");
                String commentText = rs.getString("comment_text");
                comments.add(new Comment(id, String.valueOf(this.postId), userId, commentText));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error loading comments for post ID: " + this.postId);
        }
    }

    // Getter and Setter methods
    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getWriterId() {
        return writerId;
    }

    public void setWriterId(String writerId) {
        this.writerId = writerId;
    }

    public int getNumOfLikes() {
        return numOfLikes;
    }

    public void setNumOfLikes(int numOfLikes) {
        this.numOfLikes = numOfLikes;
    }

    public List<Comment> getComments() {
        return comments;
    }
    
    public int getId() {
        return postId;
    }
}
