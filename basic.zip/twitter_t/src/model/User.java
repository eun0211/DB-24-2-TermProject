package model;

public class User {
    private String userId;
    private int followersCount;
    private int followingCount;

    public User(String userId, int followersCount, int followingCount) {
        this.userId = userId;
        this.followersCount = followersCount;
        this.followingCount = followingCount;
    }

    public String getUserId() {
        return userId;
    }

    public int getFollowersCount() {
        return followersCount;
    }

    public int getFollowingCount() {
        return followingCount;
    }

    public void setFollowersCount(int followersCount) {
        this.followersCount = followersCount;
    }

    public void setFollowingCount(int followingCount) {
        this.followingCount = followingCount;
    }
}
