package twitter_t;

import service.PostService;
import service.UserService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import model.Post;
import model.User;

public class ProfileWindow extends JFrame {
    private String userId;
    private String currentUserId;  // 현재 로그인한 사용자 ID
    private JPanel postPanel;
    private JLabel followersLabel;  // 팔로워 수를 업데이트할 수 있도록 클래스 변수로 설정
    private JLabel followingLabel;  // 팔로잉 수를 업데이트할 수 있도록 클래스 변수로 설정
    private JButton followButton;  // 팔로우/언팔로우 버튼
    private JButton viewFollowersButton;  // 팔로워 보기 버튼
    private JButton viewFollowingButton;  // 팔로잉 보기 버튼

    public ProfileWindow(String userId, String currentUserId) {
        this.userId = userId;
        this.currentUserId = currentUserId;
        setTitle(userId + "의 프로필");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 700);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        // 프로필 정보 패널
        JPanel profileInfoPanel = new JPanel();
        profileInfoPanel.setLayout(new BoxLayout(profileInfoPanel, BoxLayout.Y_AXIS));
        profileInfoPanel.setBackground(Color.WHITE);

        JLabel userNameLabel = new JLabel("사용자 이름: " + userId);
        userNameLabel.setFont(new Font("Arial", Font.BOLD, 18));
        profileInfoPanel.add(userNameLabel);
        profileInfoPanel.add(Box.createVerticalStrut(10));

        // 사용자 정보 가져오기
        User profileUser = UserService.getUser(userId);

        // 팔로워 수 레이블 생성 후 추가
        followersLabel = new JLabel("팔로워: " + (profileUser != null ? profileUser.getFollowersCount() : 0));
        followingLabel = new JLabel("팔로잉: " + (profileUser != null ? profileUser.getFollowingCount() : 0));

        // 팔로워 버튼 추가
        viewFollowersButton = new JButton("팔로워 보기");
        viewFollowersButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        viewFollowersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> followers = UserService.getFollowers(userId);
                if (followers != null && !followers.isEmpty()) {
                    JOptionPane.showMessageDialog(ProfileWindow.this,
                        "팔로워 목록: \n" + String.join("\n", followers),
                        "팔로워 목록",
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(ProfileWindow.this,
                        "팔로워가 없습니다.",
                        "알림",
                        JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // 팔로잉 버튼 추가
        viewFollowingButton = new JButton("팔로잉 보기");
        viewFollowingButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        viewFollowingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> following = UserService.getFollowing(currentUserId);
                if (following != null && !following.isEmpty()) {
                    JOptionPane.showMessageDialog(ProfileWindow.this,
                        "팔로잉 목록: \n" + String.join("\n", following),
                        "팔로잉 목록",
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(ProfileWindow.this,
                        "팔로잉이 없습니다.",
                        "알림",
                        JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // 팔로워와 팔로잉을 수평으로 나열하는 패널
        JPanel followersPanel = new JPanel();
        followersPanel.setLayout(new BoxLayout(followersPanel, BoxLayout.X_AXIS));
        followersPanel.add(followersLabel);
        followersPanel.add(Box.createHorizontalStrut(10));
        followersPanel.add(viewFollowersButton);

        JPanel followingPanel = new JPanel();
        followingPanel.setLayout(new BoxLayout(followingPanel, BoxLayout.X_AXIS));
        followingPanel.add(followingLabel);
        followingPanel.add(Box.createHorizontalStrut(10));
        followingPanel.add(viewFollowingButton);

        profileInfoPanel.add(followersPanel);
        profileInfoPanel.add(followingPanel);
        profileInfoPanel.add(Box.createVerticalStrut(10));

        // 팔로우/언팔로우 버튼 추가
        if (!currentUserId.equals(userId)) {
            followButton = new JButton();
            updateFollowButton();  // 버튼 초기 상태 업데이트

            followButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (UserService.isFollowing(currentUserId, userId)) {
                        UserService.unfollowUser(currentUserId, userId);
                        JOptionPane.showMessageDialog(ProfileWindow.this, userId + "을(를) 언팔로우했습니다.");
                    } else {
                        UserService.followUser(currentUserId, userId);
                        JOptionPane.showMessageDialog(ProfileWindow.this, userId + "을(를) 팔로우했습니다.");
                    }
                    updateFollowButton();
                    // 팔로우/언팔로우 후 팔로워 수 업데이트
                    int newFollowerCount = UserService.getFollowerCount(userId);
                    followersLabel.setText("팔로워: " + newFollowerCount);
                }
            });
            profileInfoPanel.add(followButton);
        }

        add(profileInfoPanel, BorderLayout.NORTH);

        // 트윗 목록 패널
        postPanel = new JPanel();
        postPanel.setLayout(new BoxLayout(postPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(postPanel);
        add(scrollPane, BorderLayout.CENTER);

        updatePosts();

        setVisible(true);
    }

    private void updateFollowButton() {
        if (UserService.isFollowing(currentUserId, userId)) {
            followButton.setText("언팔로우");
        } else {
            followButton.setText("팔로우");
        }
    }

    private void updatePosts() {
        postPanel.removeAll();
        List<Post> posts = PostService.getPostsByUser(userId);

        for (Post post : posts) {
            JPanel singlePostPanel = new JPanel();
            singlePostPanel.setLayout(new BorderLayout());
            singlePostPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
            singlePostPanel.setBackground(Color.LIGHT_GRAY);

            JLabel postLabel = new JLabel("<html><b>" + post.getWriterId() + "</b>: " + post.getText() + "</html>");
            postLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            singlePostPanel.add(postLabel, BorderLayout.CENTER);

            // 삭제 버튼 (현재 사용자만 삭제 가능)
            if (currentUserId.equals(post.getWriterId())) {
                JButton deleteButton = new JButton("삭제");
                deleteButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        PostService.deletePost(post.getPostId());
                        JOptionPane.showMessageDialog(ProfileWindow.this, "게시물이 삭제되었습니다.");
                        updatePosts();  // 게시물 목록 새로 고침
                    }
                });
                singlePostPanel.add(deleteButton, BorderLayout.EAST);
            }

            postPanel.add(singlePostPanel);
            postPanel.add(Box.createVerticalStrut(10));
        }

        postPanel.revalidate();
        postPanel.repaint();
    }
}
