package twitter_t;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import service.PostService;
import service.UserService;
import model.Post;

public class ProfileFrame extends JFrame {
    private String currentUserId;

    public ProfileFrame(String userId) {
        this.currentUserId = userId;
        setTitle(userId);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 600);
        setLocationRelativeTo(null);

        JPanel panel = createProfilePanel();
        add(panel);

        setVisible(true);
    }

    private JPanel createProfilePanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.WHITE);

        // 사용자 이름 라벨
        JLabel nameLabel = new JLabel(currentUserId);
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        panel.add(nameLabel);
        panel.add(Box.createVerticalStrut(10)); // 간격 추가

        // 팔로우 및 팔로워 정보
        JPanel followInfoPanel = new JPanel();
        followInfoPanel.setLayout(new FlowLayout());

        // 팔로잉 숫자 및 버튼
        JLabel followingLabel = new JLabel("팔로잉: " + UserService.getFollowedUsers(currentUserId).size());
        JButton followedUsersButton = new JButton("팔로우한 사용자 보기");
        followedUsersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> followedUsers = UserService.getFollowedUsers(currentUserId);
                JOptionPane.showMessageDialog(null, "팔로우한 사용자 목록: " + followedUsers);
            }
        });

        // 팔로워 숫자 및 버튼
        JLabel followersLabel = new JLabel("팔로워: " + UserService.getFollowers(currentUserId).size());
        JButton followersButton = new JButton("팔로워 보기");
        followersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> followers = UserService.getFollowers(currentUserId);
                JOptionPane.showMessageDialog(null, "팔로워 목록: " + followers);
            }
        });

        // 팔로잉 및 팔로워 정보 패널에 추가
        followInfoPanel.add(followingLabel);
        followInfoPanel.add(followedUsersButton);
        followInfoPanel.add(followersLabel);
        followInfoPanel.add(followersButton);

        panel.add(followInfoPanel);
        panel.add(Box.createVerticalStrut(10)); // 팔로우 정보 간의 간격 추가

        // 사용자가 작성한 게시물 목록을 가져오기
        List<Post> userPosts = PostService.getPostsByUser(currentUserId);
        for (Post post : userPosts) {
            JPanel postPanel = new JPanel();
            postPanel.setLayout(new BorderLayout());
            postPanel.setBackground(Color.LIGHT_GRAY);
            postPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            postPanel.setPreferredSize(new Dimension(350, 100));

            // 게시물 텍스트
            JTextArea postText = new JTextArea(post.getText());
            postText.setEditable(false);
            postText.setBackground(Color.LIGHT_GRAY);
            postText.setFont(new Font("Arial", Font.PLAIN, 14));
            postText.setWrapStyleWord(true);
            postText.setLineWrap(true);
            postPanel.add(postText, BorderLayout.CENTER);

            // 삭제 버튼
            JButton deleteButton = new JButton("Delete");
            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // 게시물 삭제 로직
                    PostService.deletePost(post.getPostId());
                    JOptionPane.showMessageDialog(ProfileFrame.this, "게시물이 삭제되었습니다.");
                    dispose();
                    new ProfileFrame(currentUserId); // 다시 프로필 창을 갱신하여 띄움
                }
            });
            postPanel.add(deleteButton, BorderLayout.EAST);

            panel.add(postPanel);
            panel.add(Box.createVerticalStrut(10)); // 게시물 간의 간격 추가
        }

        return panel;
    }
}
