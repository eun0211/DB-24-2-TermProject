package twitter_t;

import service.PostService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import model.Post;
import model.Comment;
import service.UserService;

public class MainApp extends JFrame {
    private String currentUserId;
    private JPanel timelinePanel;
    private List<String> tweets;

    public MainApp(String userId) {
        this.currentUserId = userId;
        this.tweets = new ArrayList<>();

        setTitle("Twitter Clone");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 700);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        // 왼쪽 사이드바
        JPanel sidebarPanel = createSidebarPanel();
        add(sidebarPanel, BorderLayout.WEST);

        // 중앙 메인 패널
        JPanel mainPanel = createMainPanel();
        add(mainPanel, BorderLayout.CENTER);

        // 오른쪽 트렌드 패널
        JPanel trendsPanel = createTrendsPanel();
        add(trendsPanel, BorderLayout.EAST);

        updateTimeline();

        setVisible(true);
    }

    private JPanel createSidebarPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.WHITE);

        String[] menuItems = {"Notifications", "Messages"};
        for (String item : menuItems) {
            JButton button = new JButton(item);
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            button.setPreferredSize(new Dimension(150, 50));
            panel.add(button);
            panel.add(Box.createVerticalStrut(10));
        }

        JButton profileButton = new JButton(" My Profile");
        profileButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        profileButton.setPreferredSize(new Dimension(150, 50));
        profileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ProfileWindow(currentUserId, currentUserId);
            }
        });
        panel.add(profileButton);
        panel.add(Box.createVerticalStrut(10));

        
        panel.add(Box.createVerticalGlue());
        JLabel userIdLabel = new JLabel("사용자 ID: " + currentUserId);
        userIdLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(userIdLabel);

        JButton logoutButton = new JButton("로그아웃");
        logoutButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                SwingUtilities.invokeLater(LoginFrame::new);
            }
        });
        panel.add(logoutButton);

        return panel;
    }

    private JPanel createMainPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JPanel tweetPanel = new JPanel();
        tweetPanel.setLayout(new BorderLayout());
        JTextField tweetField = new JTextField("What's happening?");
        JButton postButton = new JButton("Tweet");
        JButton refreshButton = new JButton("Refresh");

        tweetPanel.add(tweetField, BorderLayout.CENTER);
        tweetPanel.add(postButton, BorderLayout.EAST);
        tweetPanel.add(refreshButton, BorderLayout.WEST);
        panel.add(tweetPanel, BorderLayout.NORTH);

        timelinePanel = new JPanel();
        timelinePanel.setLayout(new BoxLayout(timelinePanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(timelinePanel);
        panel.add(scrollPane, BorderLayout.CENTER);

        postButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tweetText = tweetField.getText().trim();
                if (!tweetText.isEmpty()) {
                    PostService.addPost(tweetText, currentUserId);
                    updateTimeline();
                    tweetField.setText("");
                } else {
                    JOptionPane.showMessageDialog(MainApp.this, "Tweet cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateTimeline();
            }
        });

        return panel;
    }

    private JPanel createTrendsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setPreferredSize(new Dimension(300, 700));
        panel.setBackground(Color.WHITE);

        JTextField searchField = new JTextField("Search Twitter");
        panel.add(searchField, BorderLayout.NORTH);

        JPanel trendsListPanel = new JPanel();
        trendsListPanel.setLayout(new BoxLayout(trendsListPanel, BoxLayout.Y_AXIS));
        JScrollPane trendsScrollPane = new JScrollPane(trendsListPanel);
        panel.add(trendsScrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void updateTimeline() {
        timelinePanel.removeAll();
        List<Post> posts = PostService.getPosts();

        for (Post post : posts) {
            JPanel tweetPanel = new JPanel();
            tweetPanel.setLayout(new BorderLayout());
            tweetPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
            tweetPanel.setBackground(Color.WHITE);
            tweetPanel.setPreferredSize(new Dimension(800, 100));

            JLabel userLabel = new JLabel(post.getWriterId());
            userLabel.setFont(new Font("Arial", Font.BOLD, 12));

            // 프로필 보기 버튼 생성
            JButton profileButton = new JButton("프로필 보기");
            profileButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // 버튼 클릭 시 프로필 창 열기
                    new ProfileWindow(post.getWriterId(), currentUserId);
                }
            });

            // 작성자 이름과 버튼을 포함한 패널
            JPanel userPanel = new JPanel();
            userPanel.setLayout(new BorderLayout());
            userPanel.add(userLabel, BorderLayout.WEST);
            userPanel.add(profileButton, BorderLayout.EAST);

            tweetPanel.add(userPanel, BorderLayout.NORTH);

            JLabel tweetLabel = new JLabel(post.getText());
            tweetLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            tweetPanel.add(tweetLabel, BorderLayout.CENTER);

            JPanel bottomPanel = new JPanel();
            bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
            bottomPanel.setBackground(Color.WHITE);

            JPanel likePanel = new JPanel();
            likePanel.setLayout(new BoxLayout(likePanel, BoxLayout.X_AXIS));
            JButton likeButton = new JButton("Like");
            JLabel likeCountLabel = new JLabel("Likes: " + post.getNumOfLikes());

            likeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    post.toggleLike(currentUserId);
                    likeCountLabel.setText("Likes: " + post.getNumOfLikes());
                    updateTimeline();
                }
            });

            likePanel.add(likeButton);
            likePanel.add(Box.createHorizontalStrut(10));
            likePanel.add(likeCountLabel);

            JButton commentButton = new JButton("Comment");
            commentButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new CommentWindow(post, currentUserId);
                }
            });

            bottomPanel.add(likePanel);
            bottomPanel.add(Box.createHorizontalStrut(10));
            bottomPanel.add(commentButton);

            tweetPanel.add(bottomPanel, BorderLayout.SOUTH);
            timelinePanel.add(tweetPanel);
        }

        timelinePanel.revalidate();
        timelinePanel.repaint();
    }

    // MainApp 클래스 내 수정된 코드
    // 새로운 창을 위한 클래스
    class CommentWindow extends JFrame {
        private String currentUserId;

        public CommentWindow(Post post, String currentUserId) {
            this.currentUserId = currentUserId; // 매개변수 할당
            setTitle("Comments for Post");
            setSize(400, 300);
            setLocationRelativeTo(null);
            setLayout(new BorderLayout());

            JPanel commentPanel = new JPanel();
            commentPanel.setLayout(new BoxLayout(commentPanel, BoxLayout.Y_AXIS));
            JScrollPane scrollPane = new JScrollPane(commentPanel);

            List<Comment> comments = post.getComments();
            for (Comment comment : comments) {
                JPanel singleCommentPanel = new JPanel();
                singleCommentPanel.setLayout(new BorderLayout());
                singleCommentPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
                JLabel commentLabel = new JLabel("<html><b>" + comment.getUserId() + "</b>: " + comment.getContent() + "</html>");
                singleCommentPanel.add(commentLabel, BorderLayout.CENTER);
                commentPanel.add(singleCommentPanel);
            }

            JTextField newCommentField = new JTextField("Add a comment...");
            JButton postCommentButton = new JButton("Post");
            postCommentButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String newCommentText = newCommentField.getText().trim();
                    if (!newCommentText.isEmpty()) {
                        post.addComment(currentUserId, newCommentText);
                        commentPanel.add(new JLabel("<html><b>" + currentUserId + "</b>: " + newCommentText + "</html>"));
                        commentPanel.revalidate();
                        newCommentField.setText("");
                    } else {
                        JOptionPane.showMessageDialog(CommentWindow.this, "Comment cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

            JPanel inputPanel = new JPanel();
            inputPanel.setLayout(new BorderLayout());
            inputPanel.add(newCommentField, BorderLayout.CENTER);
            inputPanel.add(postCommentButton, BorderLayout.EAST);

            add(scrollPane, BorderLayout.CENTER);
            add(inputPanel, BorderLayout.SOUTH);

            setVisible(true);
        }
    }
    
 
}
